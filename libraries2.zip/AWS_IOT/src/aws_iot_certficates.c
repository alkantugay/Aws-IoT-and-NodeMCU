/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWjCCAkKgAwIBAgIVAMGh72wvEs6iM6QyZsdNBqrMmZVuMA0GCSqGSIb3DQEB\n\
CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t\n\
IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0xOTA5MjcxMDQ1\n\
NTdaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh\n\
dGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDYy0BDSABROqk6i+Z2\n\
wAZHmzHgrtRuOfGI8exsDwxCZuNnswfGyyPjRtbinxRmHpavpcYLi+WXbZmwGmmL\n\
7CoxJWHDWrUaDMpTIh9wGayYBkR/ldFaW9t53CkIkrCgkk+r2B/vNQmYqRp3hlXa\n\
NKZjD+u0aTxdizfaJp2O7vKx8dzzZprTV/X1v3nemKEdcCOMEAN/h1yByn6Jqwaa\n\
mYuoDzkTeaUmLQOAZeRVdImUnuQ8+dVumAlUU0lKJBO+Df93Er4Ues34Zoix5fkX\n\
dI36ODAWtGEU/Idofffmpkl2EhkwFRgg/GJG+lDlkNeLztqNuYp8yl6e2VjOWnmA\n\
EdsHAgMBAAGjYDBeMB8GA1UdIwQYMBaAFB+S1Lc4vvT+oWI0//BNWC8+08NqMB0G\n\
A1UdDgQWBBRjjYdeQaU5ewkvJ2svmM0gBdwJtDAMBgNVHRMBAf8EAjAAMA4GA1Ud\n\
DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAPi/Uud04GLw2eoUBth5THVzR\n\
PPgV1QWBWHRxOjTYHzNM6TrewDIIjmApmIdTR2w/lDyckcU6+OF+h6Re+xE/9FdJ\n\
bx30B7apWqMQqTZB44VEsJ8lQsdKy2ldJ4Ys/hX6yusiC+q0iOLA/FL1flPbli4l\n\
E9f4yoNK7YFS42p8lQ7yQGeWpxXVp9it9yxydHxFvR46Nx43zC3T019qUv+lHpxW\n\
4R8LNKZAleX3mn8MjoKh2OP1POO+tPv6JNBzvXPg6xwepGko+1ULq9lg14rcLGoC\n\
Ce45j/G1yhrTY1vEWHOaKj7WM93250sSwHSMAfd1Es6Mlwn3USDeSbixYLLKZw==\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIEpQIBAAKCAQEA2MtAQ0gAUTqpOovmdsAGR5sx4K7UbjnxiPHsbA8MQmbjZ7MH\n\
xssj40bW4p8UZh6Wr6XGC4vll22ZsBppi+wqMSVhw1q1GgzKUyIfcBmsmAZEf5XR\n\
WlvbedwpCJKwoJJPq9gf7zUJmKkad4ZV2jSmYw/rtGk8XYs32iadju7ysfHc82aa\n\
01f19b953pihHXAjjBADf4dcgcp+iasGmpmLqA85E3mlJi0DgGXkVXSJlJ7kPPnV\n\
bpgJVFNJSiQTvg3/dxK+FHrN+GaIseX5F3SN+jgwFrRhFPyHaH335qZJdhIZMBUY\n\
IPxiRvpQ5ZDXi87ajbmKfMpentlYzlp5gBHbBwIDAQABAoIBAA42BJhkd+DbP4ye\n\
7xSJsd+vxK09yJ8RHUwkz6KlueAAbpe1nKTjXA7h7eQdGXE4QBhzfW/0U7CBdrmc\n\
gZ6ydHGUSbxMjeKPRBP/AKCQjkfI4WSbpYWOz+xFCkuNkhZ0gNR67lz31RE0xI9h\n\
Nu9+1AlaWdERtOtM3PRn45wi/bW8Th3KgJtO1fDz/+PoWj9IXXlHn4CBpfdz8d7y\n\
SEta7Tw9r0M2ynUc3J205M8PROWXPcaM3AeRrU/SY+BOWA72KIKpgcF9ooczezzp\n\
EpVYO9Pig2AMRRnStQ2ZCWmBDkVsBiLfpG+UBa7v2/d2RcwYo30dTcHhfw27T30K\n\
QIKu2IECgYEA9bJmLSbBJlVZE+9dtdiZdSmLjSa661lP0hI7N05AjzFRuRYzG/4Z\n\
3VGUUzREhiRlSOJ00IsIL/k4nu30rrHsc9s/Po+gUkJZpyMj6WWIWikyAN4bhzpN\n\
cCr6y8UYaY4UiQocLvq7z4EvYC+PAkNqJ6Y/10MQWoIH3+HEgpmWSDkCgYEA4eKS\n\
4LHdxKyt2za5XEYc8+Nnz/aGdG33fwFwVOvbkq5Xv9EOa9gGpr6y6CJf7Tgzr4Hu\n\
OJZ4MuPw+GHGBG7rOv5jNH6xPuES7uHteSUfJFDieW/rBGVr8JuKYdlsCmzb+v/3\n\
hY+Uo8IgGb/iiGOo5RgNyigh4sm6R1L6ON7kvT8CgYEA2iv/RSq7quFwxx3vlbFv\n\
mzU4ATAaHTBii8S6poKrGzwNOJB48+twZjGxxyyLiJ46/jxwxFog/BCO8bmVY6cE\n\
s2BFybTaBRF78MloczFAoecgytpvkWX5K5hOubEb22dZ3tKGckUdjsZFHmE82SKp\n\
2elrmSepFuWOPoSI7fuaEikCgYEAhJqnEOM5xkB824i3rjS2wHIKOmqFqgn4VgW5\n\
NRE02Foix0dpyOOLnA2tJ1supyrsJKcI+w1SSMXJa3aycV3QF9TI1kNduAUXQUc+\n\
SnUBYCdfnFyYQf9sK1aUGTczFrerOCFV5IFSiAPpJlSgHuMqfjrttXRz2BgGk+Jh\n\
ZEttSq8CgYEA8t1JxI1rDdDykHd5PN/NAF7znysAODJwZVjapWXper/X246lRYsx\n\
+wzSwFxAYIE3O3xSDtXzd3/nm8Y/+kppdY7Veya+vPLH2Hy35KIfeUlua/4edi9r\n\
HLXkEQjwkhXTMV8w7qZWke2FVFJM9wd+ZcgP95eqpFUu537/8/mhGoY=\n\
-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
